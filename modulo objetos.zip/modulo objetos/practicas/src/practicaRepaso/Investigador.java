/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package practicaRepaso;

/**
 *
 * @author Franco
 */
public class Investigador {
    private String nombreCompleto,especialidad;
    private int categoria;
    private Subsidio[]subsidios=new Subsidio[5];

    public Investigador(String nombreCompleto, String especialidad, int categoria) {
        this.nombreCompleto = nombreCompleto;
        this.especialidad = especialidad;
        this.categoria = categoria;
    }

    public String getNombreCompleto() {
        return nombreCompleto;
    }

    public void setNombreCompleto(String nombreCompleto) {
        this.nombreCompleto = nombreCompleto;
    }

    public String getEspecialidad() {
        return especialidad;
    }

    public void setEspecialidad(String especialidad) {
        this.especialidad = especialidad;
    }

    public int getCategoria() {
        return categoria;
    }

    public void setCategoria(int categoria) {
        this.categoria = categoria;
    }
    public void agregarSubsidio(Subsidio unSubsidio){
        int i=0;
        while(subsidios[i]!=null&&i<5)
            i++;
        subsidios[i]=unSubsidio;
    }
    public double montoTotal(){
        int j=0; double cantidad=0;
        while(subsidios[j]!=null){
            if(subsidios[j].isOtorgado()){
                 cantidad+=subsidios[j].getMontoPedido();
            }
            j++;
        }
        return cantidad;
    }
    public void darSiSubsidios(){
        for(int j=0;j<5;j++)
            subsidios[j].setOtorgado(true);
    }
    @Override
    public String toString(){
        return "mi nombre es: "+getNombreCompleto()+" mi especialidad es: "+getEspecialidad()+" mi categoria es: "+getCategoria()+" y el monto total otorgado es: "+montoTotal();
    }
    
}
