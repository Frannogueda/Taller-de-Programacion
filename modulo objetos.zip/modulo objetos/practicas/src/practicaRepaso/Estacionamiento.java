/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package practicaRepaso;

/**
 *
 * @author Franco
 */
public class Estacionamiento {
    private String nombre,direccion;
    private int horaA,horaC;
    private Auto[][]autos;

    public Estacionamiento(String unNombre,String unaDirec){
        this.setNombre(unNombre);
        this.setDireccion(unaDirec);
        this.setHoraA(8);
        this.setHoraC(21);
        autos=new Auto[5][10];
    }
    public Estacionamiento(String unNombre,String unaDirec,int hComienzo,int hFin, int pisos,int plazas){
        this.setNombre(unNombre);
        this.setDireccion(unaDirec);
        this.setHoraA(hComienzo);
        this.setHoraC(hFin);
        autos=new Auto[pisos][plazas];
    }
    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public int getHoraA() {
        return horaA;
    }

    public void setHoraA(int horaA) {
        this.horaA = horaA;
    }

    public int getHoraC() {
        return horaC;
    }

    public void setHoraC(int horaC) {
        this.horaC = horaC;
    }
    
}
