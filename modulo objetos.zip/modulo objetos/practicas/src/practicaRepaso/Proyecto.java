/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package practicaRepaso;

/**
 *
 * @author Franco
 */
public class Proyecto {
    private String nombre,nombreDirec;
    private int codigo;
    private Investigador[]investigadores=new Investigador[50];

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getNombreDirec() {
        return nombreDirec;
    }

    public void setNombreDirec(String nombreDirec) {
        this.nombreDirec = nombreDirec;
    }

    public int getCodigo() {
        return codigo;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    public Proyecto(String nombre, String nombreDirec, int codigo) {
        this.nombre = nombre;
        this.nombreDirec = nombreDirec;
        this.codigo = codigo;
    }
    public void agregarUnInvestigador(Investigador unInvestigador){
        int i=0;
        while(investigadores[i]!=null&&i<50)
            i++;
        investigadores[i]=unInvestigador;
    }
    public double dineroTotalOtorgado(){
        int i=0; double cant=0;
        while(investigadores[i]!=null){
            cant+=investigadores[i].montoTotal();
            i++;
        }
        return cant;
    }
    
    
    public void otorgarTodos(String nombre){
        int k=0;
        while(investigadores[k]!=null){
            investigadores[k].darSiSubsidios();
            k++;
        }
    }
    @Override
    public String toString(){
        String aux=" "; int i=0;
        while(investigadores[i]!=null){
            aux+=investigadores[i].toString();
            i++;
        }
        return "El nombre del proyecto es: "+getNombre()+" su codigo es: "+getCodigo()+" el nombre del director es: "+getNombre()+" el dinero total fue de : "+dineroTotalOtorgado()+" y sus invertigadores: "+aux;         
    }
}