/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package practica3;
import PaqueteLectura.GeneradorAleatorio;
public class practica4 {

    public static void main(String[] args) {
       GeneradorAleatorio.iniciar();
       Hotel h1=new Hotel(); int limite=10;Persona p1; int aumento=10;
       h1.Hotel(limite);
       for (int i=0;i<limite;i++){
           p1=new Persona(GeneradorAleatorio.generarString(3),GeneradorAleatorio.generarInt(30),GeneradorAleatorio.generarInt(30));
           h1.ingresarPersona(p1,i);   
       }
       for(int j=0;j<limite;j++){//imprime en un bucle las habitaciones/ preguntar al profe 
            System.out.println(h1.toString(j));
       }   
       h1.subimosElPrecio(aumento);//aumento el precio en 10 
        System.out.println("-------------");
       for(int h=0;h<limite;h++){//imprime con el aumento
            System.out.println(h1.toString(h));
       }
    }
}
