/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package practica3;

public class Habitacion {
    private double costoNoche;
    private boolean ocupada;
    private Persona cliente;

    public Habitacion(double unCosto,boolean estaOcupada){
        costoNoche=unCosto;
        ocupada=estaOcupada;
    }
    public double getCostoNoche() {
        return costoNoche;
    }

    public void setCostoNoche(double costoNoche) {
        this.costoNoche = costoNoche;
    }

    public String estaOcupada() {
        if(ocupada==false)
            return "esta ocupada";
        else
            return "esta disponible";
    }

    public void setOcupada(boolean ocupada) {
        this.ocupada = ocupada;
    }

    public Persona getCliente() {
        return cliente;
    }

    public String toString(int x) {
        return "Habitacion: "+ x + "costoNoche=" + costoNoche + ", ocupada=" + ocupada + ", cliente=" + cliente + '}';
    }

    public void setCliente(Persona uncliente) {
        cliente = uncliente;
    }
    public void aumentito(double num){
        costoNoche+=num;
    }
}