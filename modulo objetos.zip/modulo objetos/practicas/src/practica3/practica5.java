/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package practica3;
import PaqueteLectura.Lector;
public class practica5 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       Circulo c1;
       System.out.println("ingrese el radio");
       double r1=Lector.leerDouble();
       System.out.println("ingresa el color de relleno");
       String color1=Lector.leerString();
       System.out.println("ingresa el color de la linea");
       String color2=Lector.leerString();
       c1=new Circulo(r1,color1,color2);
       System.out.println(c1.calcularArea());
       System.out.println(c1.calcularPerimetro());
       System.out.println(c1.toString());
    }
    
}
