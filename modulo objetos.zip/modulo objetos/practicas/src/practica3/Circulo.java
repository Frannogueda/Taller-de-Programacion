/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package practica3;

/**
 *
 * @author frann
 */
public class Circulo {
    private double radio;
    private String relleno,colorLinea;

    public Circulo(double unRadio,String unRelleno,String unColorLinea){
        radio=unRadio;
        relleno=unRelleno;
        colorLinea=unColorLinea;
    }
    public double getRadio() {
        return radio;
    }

    public void setRadio(double radio) {
        this.radio = radio;
    }

    public String getRelleno() {
        return relleno;
    }

    public void setRelleno(String relleno) {
        this.relleno = relleno;
    }

    public String getColorlinea() {
        return colorLinea;
    }

    public void setColorlinea(String colorlinea) {
        this.colorLinea = colorlinea;
    }
    public double calcularPerimetro(){
        return 2*Math.PI*radio;
    }

    @Override
    public String toString() {
        return "Circulo{" + "radio=" + radio + ", relleno=" + relleno + ", colorLinea=" + colorLinea + '}';
    }
    public double calcularArea(){
        return Math.PI*radio*radio;
    }
}

