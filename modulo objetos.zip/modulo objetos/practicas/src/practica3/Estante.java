/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package practica3;

/**
 *
 * @author Franco
 */
public class estante {
    private int espacio;
    private int nuevo=0;
    private Libro [] libros;
    
    public void estante(int num){//Inciso C. pones el valor que queres y si lo asigna en el espacio del estante
        espacio=num;
        libros=new Libro[espacio];
        for (int i=0;i<espacio;i++)
            libros[i]=null;
    }
    
    public int cantLibros(){//cantidad de libros
        return nuevo;
    }
    public boolean estaLleno(){//chequea si esta lleno el estante
        return (nuevo==espacio);
    }
    public void agregarLibro(Libro l){// agrega un libro al estante 
        if(nuevo<espacio){
            libros[nuevo]=l;
            nuevo++;
        }else{
            System.out.println("no hay espacio");
        }
    }
    public String devolverLibro(String x){// busca un libro en el vector del estante
        int j=nuevo; boolean encontre=true;
        String aux=" ";
        while(j<espacio && !encontre){
            aux=libros[j].getTitulo();
            if(aux.equals(x)){
                encontre=true;
            }else
                j++;
        }
        if(aux.equals(x))
            return aux;
        else
            return("no se encontro el libro");
    }
    
    public String toString(int x) {
        return "Estante en el lugar: "+ x + libros[x].toString();
    }
}
