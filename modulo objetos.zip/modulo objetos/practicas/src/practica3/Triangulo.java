/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package practica3;

/**
 *
 * @author Franco
 */
public class Triangulo {
    private double lado1,lado2,lado3;
    private String borde,relleno;
    
    public Triangulo(double unLado1,double unLado2,double unLado3,String unBorde,String unRelleno){
        lado1=unLado1;
        lado2=unLado2;
        lado3=unLado3;
        borde=unBorde;
        relleno=unRelleno;
    }
    public double getlado1(){
        return lado1;
    }
    public double getlado2(){
        return lado2;
    }
    public double getlado3(){
        return lado3;
    }
    public String getborde(){
        return borde;
    }
    public String getrelleno(){
        return relleno;
    }
    public void setlado1(double unLado1){
        lado1=unLado1;
    }
    public void setlado2(double unLado2){
        lado2=unLado2;
    }
    public void setlado3(double unLado3){
        lado3=unLado3;
    }
    public void setborde(String unBorde){
        borde=unBorde;
    }
    public void setrelleno(String unRelleno){
        relleno=unRelleno;
    }
    public double calcularPerimetro(){
        return (lado1+lado2+lado3);
    }
    public double calcularArea(){
        double s=lado1+lado2+lado3/2;
        return (Math.sqrt(s*(s-lado1)*(s-lado2)*(s-lado3)));
    }
}
