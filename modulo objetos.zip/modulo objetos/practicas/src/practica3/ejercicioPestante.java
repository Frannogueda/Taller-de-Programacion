/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package practica3;

/**
 *
 * @author frann
 */
public class ejercicioPestante {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        estante h1=new estante(); autor a1=new autor(); Libro l1;
        int x=20;
        h1.estante(x);
        l1=new Libro("a","rayuela",a1,"233");
        l1.getPrimerAutor().getNombre();
        h1.agregarLibro(l1);
        System.out.println(h1.cantLibros());
        System.out.println(h1.estaLleno());
        System.out.println(h1.toString(0));
    }
    
}
