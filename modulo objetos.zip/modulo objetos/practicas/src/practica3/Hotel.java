/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package practica3;
import PaqueteLectura.GeneradorAleatorio;

public class Hotel {
    private Habitacion [] habitaciones;
    private int NumeroH;
    
    public void ini(){
    }
    
    public void Hotel(int num){
        NumeroH=num;
        GeneradorAleatorio.iniciar();
        habitaciones=new Habitacion[NumeroH];
         for (int i=0;i<NumeroH;i++)
            habitaciones[i]=new Habitacion(GeneradorAleatorio.generarDouble(3000),false);
    } 
    public void Hotel(){
    }
    public void ingresarPersona(Persona p, int x){
        if(habitaciones[x].estaOcupada().equals("esta ocupada")){
            habitaciones[x].setCliente(p);
            habitaciones[x].setOcupada(true);
        }else
                System.out.print("ya esta en reserva");
    }
    public void subimosElPrecio(double num){
        for(int j=0;j<NumeroH;j++)
            habitaciones[j].aumentito(num);
    }
    
    public String toString(int h){//no imprime el string completo
            return "la habitacion"+ h +" costo: "+habitaciones[h].getCostoNoche()+" esta habitacion se encuentra: "+habitaciones[h].estaOcupada()+habitaciones[h].getCliente();  
    }
}
