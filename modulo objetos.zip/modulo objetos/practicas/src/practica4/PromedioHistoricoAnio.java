/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package practica4;

/**
 *
 * @author frann
 */
public class PromedioHistoricoAnio extends Estacion{
    private double promedioHAnio;

    public PromedioHistoricoAnio(String unNombre,double unaLatitud,double unaLonguitud){
        super(unNombre,unaLatitud,unaLonguitud);
    }
    public double getPromedioHAnio() {
        return promedioHAnio;
    }

    public void setPromedioHAnio(double promedioHAnio) {
        this.promedioHAnio = promedioHAnio;
    }
}
