/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package practica4;

/**
 *
 * @author Franco
 */
public class practica1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Circulo c1=new Circulo(30,"dorado","pantano");
        Triangulo tri=new Triangulo(10,10,20,"rojo","verde");
        System.out.println(tri.toString());
        System.out.println(c1.toString());
        tri.despintar();
        c1.despintar();
        System.out.println(tri.toString());
        System.out.println(c1.toString());
    }
    
}
