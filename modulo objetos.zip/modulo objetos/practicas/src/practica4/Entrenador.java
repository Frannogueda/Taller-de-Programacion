/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package practica4;

/**
 *
 * @author frann
 */
public class Entrenador extends Empleado{
    private int cantCampeonatosG;

    public int getCantCampeonatosG() {
        return cantCampeonatosG;
    }

    public Entrenador(String nombre, double sueldo, int antiguedad,int cantCampeonatosG) {
        super(nombre, sueldo, antiguedad);
        this.cantCampeonatosG = cantCampeonatosG;
    }

    public void setCantCampeonatosG(int cantCampeonatosG) {
        this.cantCampeonatosG = cantCampeonatosG;
    }
    public double calcularEfectividad(){
        return getCantCampeonatosG()/getAntiguedad();//no esta claro como sacar la efectividad, preguntar 
    }
    @Override
    public double calcularSueldoACobrar(){
        if(this.getCantCampeonatosG()==0)
            return this.getSueldoBasico();
        else
            if(this.getCantCampeonatosG()>1&&this.getCantCampeonatosG()<4)
                return (this.getSueldoBasico()+5000);
            else
                if(this.getCantCampeonatosG()>5&&this.getCantCampeonatosG()<10)
                    return(this.getSueldoBasico()+30000);
                else
                    if(this.getCantCampeonatosG()>10)
                        return (this.getSueldoBasico()+50000);
        return 0;
            }
        }
        
    

