/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package practica4;

/**
 *
 * @author frann
 */
public class PromedioHistoricoMes extends Estacion{
    private double promHMes;
    
    public PromedioHistoricoMes(String unNombre,double unaLatitud,double unaLonguitud){
        super(unNombre,unaLatitud,unaLonguitud);
    }

    public double getPromHMes() {
        return promHMes;
    }

    public void setPromHMes(double promHMes) {
        this.promHMes = promHMes;
    }
}
