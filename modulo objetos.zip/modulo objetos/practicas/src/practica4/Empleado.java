/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package practica4;

/**
 *
 * @author frann
 */
public abstract class Empleado {
    private String Nombre;
    private double SueldoBasico;
    private int Antiguedad;
    
    public Empleado(String nombre,double sueldo,int antiguedad){
        setNombre(nombre);
        setSueldoBasico(sueldo);
        setAntiguedad(antiguedad);
    }
    public String toString(){
        return "mi nombre es: "+getNombre()+" mi sueldo es de: "+this.calcularSueldoACobrar()+" y mi efectividad es: "+this.calcularEfectividad();
    }

    public String getNombre() {
        return Nombre;
    }

    public void setNombre(String Nombre) {
        this.Nombre = Nombre;
    }

    public double getSueldoBasico() {
        return SueldoBasico;
    }

    public void setSueldoBasico(double SueldoBasico) {
        this.SueldoBasico = SueldoBasico;
    }

    public int getAntiguedad() {
        return Antiguedad;
    }

    public final void setAntiguedad(int Antiguedad) {
        this.Antiguedad = Antiguedad;
    }
    public abstract double calcularEfectividad();
    public abstract double calcularSueldoACobrar();
}
