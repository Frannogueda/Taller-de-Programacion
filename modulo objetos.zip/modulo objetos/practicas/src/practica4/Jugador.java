/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package practica4;

/**
 *
 * @author frann
 */
public class Jugador extends Empleado{
    private int partidosJ,goles;
    
    public Jugador(String nombre,double sueldo,int antiguedad,int partidosJ,int goles){
        super(nombre,sueldo,antiguedad);
        this.setPartidosJ(partidosJ);
        this.setGoles(goles);
    }

    public int getPartidosJ() {
        return partidosJ;
    }

    public void setPartidosJ(int partidosJ) {
        this.partidosJ = partidosJ;
    }

    public int getGoles() {
        return goles;
    }

    public void setGoles(int goles) {
        this.goles = goles;
    }
    public double calcularEfectividad(){
        return getPartidosJ()/getGoles();
    }
    public double calcularSueldoACobrar(){
        double plusAnio=10*this.getSueldoBasico()/100;
        double promedioJugado=this.getPartidosJ()/this.getGoles();
        plusAnio=plusAnio*this.getAntiguedad();
        if(promedioJugado>0.5)
            return (this.getSueldoBasico()+plusAnio+this.getSueldoBasico());
            else
            return(this.getSueldoBasico()+plusAnio); 
    }
   
}
