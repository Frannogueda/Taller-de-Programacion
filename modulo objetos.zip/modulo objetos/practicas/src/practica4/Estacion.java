/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package practica4;

import PaqueteLectura.GeneradorAleatorio;
//matriz para el anio y los meses. iniciarlo con datos randoms cuando iniciamos el constructor 

public abstract class Estacion {
    private String nombre;
    private double latitud,longuitud,temperatura;
    private int anioC,anioF;
    
    public Estacion(String unNombre,double unaLatitud,double unaLonguitud){
        setNombre(unNombre);
        setLatitud(unaLatitud);
        setLonguitud(unaLonguitud);
    }
    public void anioComienzoYFin(int comienzo,int fin){
        setAnioC(comienzo);
        setAnioF(fin);
        GeneradorAleatorio.iniciar();
        setTemperatura(GeneradorAleatorio.generarDouble(3000));
    }
    public Estacion(){
    
    }

    public double getTemperatura() {
        return temperatura;
    }

    public void setTemperatura(double temperatura) {
        this.temperatura = temperatura;
    }

    public int getAnioC() {
        return anioC;
    }

    public void setAnioC(int anioC) {
        this.anioC = anioC;
    }

    public int getAnioF() {
        return anioF;
    }

    public void setAnioF(int anioF) {
        this.anioF = anioF;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public double getLatitud() {
        return latitud;
    }

    public void setLatitud(double latitud) {
        this.latitud = latitud;
    }

    public double getLonguitud() {
        return longuitud;
    }

    public void setLonguitud(double longuitud) {
        this.longuitud = longuitud;
    }
}
