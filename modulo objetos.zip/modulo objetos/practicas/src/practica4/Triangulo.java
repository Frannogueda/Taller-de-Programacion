/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package practica4;

/**
 *
 * @author Franco
 */
public class Triangulo extends Figura{
    private double lado1,lado2,lado3;
    
    public Triangulo(double unLado1,double unLado2,double unLado3,String unBorde,String unRelleno){
        super(unRelleno,unBorde);
        setlado1(unLado1);
        setlado2(unLado2);
        setlado3(unLado3);
    }
    public double getlado1(){
        return lado1;
    }
    public double getlado2(){
        return lado2;
    }
    public double getlado3(){
        return lado3;
    }
    
    public final void setlado1(double unLado1){
        lado1=unLado1;
    }
    public final void setlado2(double unLado2){
        lado2=unLado2;
    }
    public final void setlado3(double unLado3){
        lado3=unLado3;
    }

    @Override
    public String toString() {
        return "Triangulo" + " lado1=" + lado1 + ", lado2=" + lado2 + ", lado3=" + lado3 + super.toString();
    }
    @Override
    public double calcularPerimetro(){
        return (lado1+lado2+lado3);
    }
    @Override
    public double calcularArea(){
        double s=lado1+lado2+lado3/2;
        return (Math.sqrt(s*(s-lado1)*(s-lado2)*(s-lado3)));
    }
}
