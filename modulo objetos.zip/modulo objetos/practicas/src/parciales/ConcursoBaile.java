/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package parciales;

/**
 *
 * @author Franco
 */
public class ConcursoBaile {
    private int espacio;
    private Pareja[]parejas;

public void ConcursoBaile(int n){
    this.espacio=n;
    parejas=new Pareja[espacio];
}
public void agregarPareja(Pareja p){//inceiso b1
    int i=0;
    while(parejas[i]!=null)
        i++;
    parejas[i]=p;
}

public int diferenciaPareja(Pareja p){// inciso b2
    return Math.abs(p.getPersona1().getEdad()-p.getPersona2().getEdad());
}

public Pareja maximaDiferencia(){
    int j,max=0; Pareja ParejaM;
    for (j=0;j<espacio;j++)
        if(diferenciaPareja(parejas[j])>max)
            max=diferenciaPareja(parejas[j]);
            ParejaM=parejas[j];
    return ParejaM;
}

}