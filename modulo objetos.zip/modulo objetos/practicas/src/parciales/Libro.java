/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package parciales;

/**
 *
 * @author frann
 */
public abstract class Libro {
    private String titulo;
    private double precioBase;
    private String[]autores=new String[8];
    
    public Libro(String unTitulo,double precio){
        this.setTitulo(unTitulo);
        this.setPrecioBase(precio);
    }
    public void agregarAutor(String unAutor){
        int i=0;
        while(autores[i]!=null&&i<8)
            i++;
        autores[i]=unAutor;
    }
    public String toString(){
        String tipos=" "; int j=0;
        while(autores[j]!=null&&j<8){
            tipos+=" "+autores[j];
            j++;
        }
        return "el titulo: "+ this.getTitulo()+" el precio total: "+this.precioFinal()+" los autores: "+ tipos;
    }
    public abstract double precioFinal();

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public double getPrecioBase() {
        return precioBase;
    }

    public void setPrecioBase(double precioBase) {
        this.precioBase = precioBase;
    }
}
