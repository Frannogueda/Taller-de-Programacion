/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package parciales;

/**
 *
 * @author frann
 */
public class Psicologo {
    private Paciente[][]pacientes=new Paciente[5][6];
    
    public void Psicologo(){
        for(int i=0;i<5;i++)
            for(int j=0;j<6;j++)
                pacientes[i][j]=null;
    } 
    
    public void agendarPaciente(Paciente p,int dia,int turno){
        if(pacientes[dia][turno]==null){
            pacientes[dia][turno]=p;
        }
    }
    
   public void liberarSusTurnos(String pacienteB){
       for(int i=0;i<5;i++)
           for(int j=0;j<6;j++)
               if(pacientes[i][j].getNombre().equals(pacienteB))
                   pacientes[i][j]=null;
   } 
   
   public String tieneTurno(int unDia,String nombreP){
       String aux="no se encontro"; boolean encontre=true;
       for(int j=0;j<6&&!encontre!=false;j++)
           if(pacientes[unDia][j].getNombre().equals(nombreP)){
               aux="tiene el turno"+ (1+j);
               encontre=true;
           }
        return aux;       
   }
}
