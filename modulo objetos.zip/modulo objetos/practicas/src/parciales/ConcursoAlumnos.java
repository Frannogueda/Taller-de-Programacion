/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package parciales;

/**
 *
 * @author frann
 */
public class ConcursoAlumnos {
    private Alumno[][]alumnos;
    private int max;

    public ConcursoAlumnos(int n){
        setMax(n);
        alumnos=new Alumno[4][max];
        for (int i=0;i<4;i++)
            for(int j=0;j<max;j++)
                alumnos[i][j]=null;
    }
    public void inscribirAlu(Alumno a,int genero){
        int h=0;
        while(alumnos[genero][h]!=null)
            h++;
        alumnos[genero][h]=a;
    }
    public void asignarPuntaje(String nombreAlu,double unPuntaje){
       boolean encontre=true;
       int i=0,j=0;
       while(i<4&&!encontre)
           while(j<max)
               if(alumnos[i][j].getNombre().equals(nombreAlu)){
                   encontre=true;
                   alumnos[i][j].setPuntaje(unPuntaje);
               }else
                   j++;
          i++;           
    }
    public int maximoGeneros(){
        int Max=0,cant=0;
        for(int k=0;k<4;k++){
            cant=0;
            for(int j=0;j<Max;j++)
                if(alumnos[k][j]!=null)
                    cant++;
            if(cant>Max)
                Max=cant;
         }
        return cant;
    }

    public Alumno[][] getAlumnos() {
        return alumnos;
    }

    public void setAlumnos(Alumno[][] alumnos) {
        this.alumnos = alumnos;
    }

    public int getMax() {
        return max;
    }

    public void setMax(int max) {
        this.max = max;
    }
    
}
