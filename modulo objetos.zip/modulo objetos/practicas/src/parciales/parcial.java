/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package parciales;

import PaqueteLectura.GeneradorAleatorio;
public class parcial {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       GeneradorAleatorio.iniciar();
       Paciente p; Psicologo escenario=new Psicologo(); int dia,turno;
       for(int i=0;i<5;i++)
           for(int j=0;j<3;j++){
               dia=GeneradorAleatorio.generarInt(4);
               turno=GeneradorAleatorio.generarInt(5);
               p=new Paciente(GeneradorAleatorio.generarString(3),GeneradorAleatorio.generarBoolean(),GeneradorAleatorio.generarDouble(3000));
               escenario.agendarPaciente(p, dia, turno); 
           }
           //falta cargar los datos
    }
    
}
