/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package parciales;

/**
 *
 * @author frann
 */
public class Vehiculo {
    private int patente;
    private int cantHoras;

    public Vehiculo(int patente, int cantHoras, String marca, String modelo) {
        this.patente = patente;
        this.cantHoras = cantHoras;
        this.marca = marca;
        this.modelo = modelo;
    }

    @Override
    public String toString() {
        return "Vehiculo{" + "patente=" + patente + ", cantHoras=" + cantHoras + ", marca=" + marca + ", modelo=" + modelo + '}';
    }
    
    private String marca,modelo;

    public int getPatente() {
        return patente;
    }

    private void setPatente(int patente) {
        this.patente = patente;
    }

    public int getCantHoras() {
        return cantHoras;
    }

    private void setCantHoras(int cantHoras) {
        this.cantHoras = cantHoras;
    }

    public String getMarca() {
        return marca;
    }

    private void setMarca(String marca) {
        this.marca = marca;
    }

    public String getModelo() {
        return modelo;
    }

    private void setModelo(String modelo) {
        this.modelo = modelo;
    }
}
