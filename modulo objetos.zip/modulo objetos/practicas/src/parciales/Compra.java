/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package parciales;

/**
 *
 * @author frann
 */
public abstract class Compra {
    private int numero;
    private int dl;
    private Producto[]productos;
    
    public Compra(int unNumero,int cantPC){
        this.setNumero(unNumero);
        this.productos=new Producto[cantPC];
        this.setDl(cantPC);
        for(int i=0;i<cantPC;i++)
            productos[i]=null;
    }

    public int getDl() {
        return dl;
    }

    private void setDl(int dl) {
        this.dl = dl;
    }
    
    public void agregaCompra(Producto p){
        int j=0;
        while(j<this.getDl()&&productos[j]!=null){
            j++;
        }   
        productos[j]=p;
    }
    public double obtenerPrecioAPagar(){
        double cantTotal=0,aux=0; int h=0;
        while(h<this.getDl()&&productos[h]!=null){
            cantTotal+=productos[h].getPrecio();
            h++;
        }
        aux=21*cantTotal/100;
        cantTotal+=aux;
        return cantTotal;
    }
    @Override
    public String toString(){
        String aux=" ",productitos=" "; int y=0;
        while(y<this.getDl()&&productos[y]!=null){
            productitos+=productos[y].toString();
            y++;
        }
        aux="el numero: "+getNumero()+" los productos: "+productitos+" el precio total: "+obtenerPrecioAPagar();
        return aux;
    } 

    public int getNumero() {
        return numero;
    }

    public void setNumero(int numero) {
        this.numero = numero;
    }
}
