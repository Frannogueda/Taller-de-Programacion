/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package parciales;

/**
 *
 * @author frann
 */
public class libritos {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       LibroElectronico le; LibroImpreso li;
       le=new LibroElectronico("cositas",20.2,".pdf",5);
       li=new LibroImpreso("costa",20.7,true);
       le.agregarAutor("franco");
       le.agregarAutor("luis");
       li.agregarAutor("trava");
       li.agregarAutor("luisa");
       li.agregarAutor("adriana");
       System.out.println(le.toString());
       System.out.println(li.toString());
    }
    
}
