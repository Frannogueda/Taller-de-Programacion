/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package parciales;

/**
 *
 * @author frann
 */
public class Mayorista extends Compra{
    private int cuit;
    
    public Mayorista(int unNumeroP,int cantPC,int unCuit){
        super(unNumeroP,cantPC);
        this.setCuit(unCuit);
    }
    @Override
    public void agregaCompra(Producto p){
        super.agregaCompra(p);
    }
    public int getCuit() {
        return cuit;
    }
    @Override
    public double obtenerPrecioAPagar(){
        return super.obtenerPrecioAPagar();
    }
    @Override
    public String toString(){
        return super.toString()+ "el cuit: "+this.getCuit();
    }

    private void setCuit(int cuit) {
        this.cuit = cuit;
    }
}
