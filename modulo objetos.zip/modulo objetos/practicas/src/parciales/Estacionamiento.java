/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package parciales;

/**
 *
 * @author frann
 */
public class Estacionamiento {
    private String direc;
    private double costoPorHora;
    private Vehiculo[][] vehiculos;
    private int dimSectores,dimLugares;
    
    public Estacionamiento(String unaDirec,double unCosto,int Sector,int numeroXSector){
        this.setDirec(unaDirec);
        this.setCostoPorHora(unCosto);
        dimSectores=Sector;
        dimLugares=numeroXSector;
        vehiculos=new Vehiculo[Sector][numeroXSector];
    }
    public void registrarAuto(Vehiculo v,int x,int y){
        if(vehiculos[x][y]==null){
            vehiculos[x][y]=v;
            System.out.println(vehiculos[x][y].toString());
        }
    }
    
    public String liberarLugares(String marcaB,int x){
        String aux="";
        for(int i=0;i<this.dimSectores;i++){
            if(vehiculos[x][i].getMarca().equals(marcaB)){
                aux+=vehiculos[x][i].toString();
                vehiculos[x][i]=null;
            }
        }
        return aux;  
    }
    public int sectorMayorRecaudo(){
        double max,maxTotal=0; int secMax=0;
        for(int i=0;i<this.dimSectores;i++){
            max=0;
            for(int j=0;j<dimLugares;j++){
                max+=vehiculos[i][j].getCantHoras()*this.getCostoPorHora();
            }  
            if(max>maxTotal){
                maxTotal=max;
                secMax=i;
            }
        }  
        return secMax;
    }
    @Override
    public String toString(){
        String aux=""; 
        System.out.println("---------------");
        for(int i=0;i<this.dimSectores;i++){
            aux+="el sector: "+i+"tiene estos autos: ";
            System.out.println("0000000000000000000000");
            for(int j=0;j<this.dimLugares;j++){
                aux+=vehiculos[i][j].toString();
            }    
        }
        return "el estacionamiento se encuentra: "+this.getDirec()+" el costo por hora: "+this.getDirec()+" y sus sectores"+aux;
    }

    public String getDirec() {
        return direc;
    }

    private void setDirec(String direc) {
        this.direc = direc;
    }

    public double getCostoPorHora() {
        return costoPorHora;
    }

    private void setCostoPorHora(double costoPorHora) {
        this.costoPorHora = costoPorHora;
    }
}
