/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package parciales;

/**
 *
 * @author frann
 */
public class LibroImpreso extends Libro{
    private boolean tapadura;
    
    public LibroImpreso(String unTitulo,double precio,boolean esTapa){
        super(unTitulo,precio);
        this.setTapadura(esTapa);
    }
    @Override
    public double precioFinal(){
        if(this.isTapadura())
            return this.getPrecioBase()+500;
        else
            return this.getPrecioBase();
    }
    @Override
    public String toString(){
        return super.toString();
    }

    public boolean isTapadura() {
        return tapadura;
    }

    public void setTapadura(boolean tapadura) {
        this.tapadura = tapadura;
    }
}
