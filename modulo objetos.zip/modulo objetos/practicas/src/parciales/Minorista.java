/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package parciales;

/**
 *
 * @author frann
 */
public class Minorista extends Compra{
    private boolean jubilado;
    
    public Minorista(int unNumeroP,int cantPC,boolean jubilacion){
        super(unNumeroP,cantPC);
        this.setJubilado(jubilacion);
    }
    @Override
    public void agregaCompra(Producto p){
        super.agregaCompra(p);
    }
    @Override
    public double obtenerPrecioAPagar(){
        return super.obtenerPrecioAPagar();
    }
    @Override
    public String toString(){
        return super.toString()+" Es Jubilado: "+ this.isJubilado();
    }

    public boolean isJubilado() {
        return jubilado;
    }

    private void setJubilado(boolean jubilado) {
        this.jubilado = jubilado;
    }
    
}
