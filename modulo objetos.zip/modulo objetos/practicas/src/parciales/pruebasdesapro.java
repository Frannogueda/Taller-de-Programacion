/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package parciales;

/**
 *
 * @author frann
 */
public class pruebasdesapro {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       Estacionamiento esta1; Vehiculo v1,v2,v3;
       esta1=new Estacionamiento("chacabuco",20.3,10,10);
       v1=new Vehiculo(234,2,"prueba1","cosa");
       v2=new Vehiculo(231,1,"cosa","ëre");
       v3=new Vehiculo(134,5,"grtgr","rtyy");
       esta1.registrarAuto(v1,3,0);
       esta1.registrarAuto(v2,0,0);
        System.out.println(esta1.toString());
    }
    
}
