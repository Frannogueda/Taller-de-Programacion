/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package parciales;

/**
 *
 * @author frann
 */
public class LibroElectronico extends Libro{
    private String formato;
    private int tamanioMB;
    
    public LibroElectronico(String unTitulo,double precio,String unFormato,int unTamanio){
        super(unTitulo,precio);
        this.setFormato(unFormato);
        this.setTamanioMB(unTamanio);
    }

    public String getFormato() {
        return formato;
    }
    @Override
    public String toString(){
        return super.toString();
    }
    @Override
    public double precioFinal(){
        return this.getPrecioBase()+(2.5*this.getTamanioMB());
    }

    public void setFormato(String formato) {
        this.formato = formato;
    }

    public int getTamanioMB() {
        return tamanioMB;
    }

    public void setTamanioMB(int tamanioMB) {
        this.tamanioMB = tamanioMB;
    }
}
