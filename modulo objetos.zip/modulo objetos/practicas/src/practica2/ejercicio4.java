/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package practica2;

import PaqueteLectura.GeneradorAleatorio;

/**
 *
 * @author frann
 */
public class ejercicio4 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        GeneradorAleatorio.iniciar();
        Persona p1; int pos,i=0;
        int dias=5;
        p1=new Persona(GeneradorAleatorio.generarString(3),GeneradorAleatorio.generarInt(50),GeneradorAleatorio.generarInt(90));
        pos=GeneradorAleatorio.generarInt(dias);//posicion del dia
        
        Persona[][]casting=new Persona[dias][8];
        int []inscriptos=new int[dias];
        for (int u=0;u<dias;u++){
            inscriptos[u]=0;//inicializo el contador
        }
        for (int u = 0; u < dias; u++) {
            for (int j = 0; j < 8; j++) {
                 casting[u][j] = null; // Inicializar cada posición del casting a null
             }
        }
        while(!p1.getNombre().equals("zzz")&&i<40){//bucle principal ;"i"lleva el contador de personas
            int turno=-1;
            for (int j=0;j<8&&turno==-1;j++){//busca el primer turno del dia asignando la posicion en j
                if(casting[pos][j]==null)
                    turno=j;
            }
            if(turno!=-1){//pregunta si hay espacio en el para el dia 
                casting[pos][turno]=p1;
                inscriptos[pos]++;
                pos=GeneradorAleatorio.generarInt(dias);
                System.out.println(p1.toString());
                i++;
                p1=new Persona(GeneradorAleatorio.generarString(3),GeneradorAleatorio.generarInt(50),GeneradorAleatorio.generarInt(90));
                }else{//si no hay lugar ese dia se le asigna otro dia
                     System.out.println("no hay turnos disponibles en el dia");
                     System.out.println("elija un dia habil");
                     pos=GeneradorAleatorio.generarInt(dias);
                 }
            }
        for (int dia = 0; dia < dias; dia++) {
            System.out.println("Día " + (dia + 1) + ": " + inscriptos[dia] + " inscritos.");
            for (int turno = 0; turno < 8; turno++) {
                if (casting[dia][turno] != null) {
                    System.out.println("Turno " + (turno + 1) + ": " + casting[dia][turno].getNombre());
                            }
        }
        }
    }
}