/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package practica2;
import PaqueteLectura.Lector;
public class ejercicio5 {

    public static void main(String[] args) {
        int i=0; Partido p1; int k; int df=19;
      Partido[]juegos=new Partido[df];
      for (k=0;k<df;k++)
          juegos[k]=null;
      System.out.println("ingrese el equipo local: ");
      String unLocal=(Lector.leerString());
      System.out.println("ingrese el equipo visitante: ");
      String unVisitante=(Lector.leerString());
      System.out.println("la cantidad de goles que hizo el equipo local: ");
      int lGol=Lector.leerInt();
      System.out.println("la cantidad de goles que hizo el equipo visitante: ");
      int vGol=Lector.leerInt();
      juegos[i]=p1=new Partido(unLocal,unVisitante,lGol,vGol);
      while(!unVisitante.equals("zzz")&&i<df){
          System.out.println("ingrese el equipo local: ");
          unLocal=(Lector.leerString());
          System.out.println("ingrese el equipo visitante: ");
          unVisitante=(Lector.leerString());
          if(!unVisitante.equals("zzz")){
             System.out.println("la cantidad de goles que hizo el equipo local: ");
             lGol=Lector.leerInt();
             System.out.println("la cantidad de goles que hizo el equipo visitante: ");
             vGol=Lector.leerInt();
              i++;
             juegos[i]=p1=new Partido(unLocal,unVisitante,lGol,vGol);
          }
         }
       System.out.println("=========");
      int cantPGR=0,golesTB=0,j=0;
      while(j<=i){
            System.out.println(juegos[j].getLocal()+" "+juegos[j].getGolesLocal()+" VS "+juegos[j].getVisitante()+" "+juegos[j].getGolesVisitante());
            if(juegos[j].getLocal().equals("river")){
                if(juegos[j].getGanador().equals("river"))
                    cantPGR++;
            }
            if(juegos[j].getVisitante().equals("river")){
                if(juegos[j].getGanador().equals("river"))
                    cantPGR++;      
            }
            if(juegos[j].getLocal().equals("boca"))
                golesTB+=juegos[j].getGolesLocal();
            if(juegos[j].getVisitante().equals("boca"))
                golesTB+=juegos[j].getGolesVisitante();
            j++;
      }
      System.out.println("la cantidad de partidos que gano river fue: "+cantPGR);
      System.out.println("la cantidad de goles que hice boca fueron de: "+golesTB);
    }
}
