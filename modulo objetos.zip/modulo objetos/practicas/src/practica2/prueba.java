/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package practica2;

/**
 *
 * @author Franco
 */
public class prueba {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Persona p1;
        p1=new Persona("franco",23,34);
        System.out.println(p1.getNombre());
        p1.setNombre("pepe");
        System.out.println(p1.getNombre());
        System.out.println(p1.getNombre());
        
    }
    
}
