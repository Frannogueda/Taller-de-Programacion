/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package practica2;
import PaqueteLectura.GeneradorAleatorio;
public class ejercicio3 {

    /**
     * @param args the command line arguments
     */

    public static void main(String[] args) {
        GeneradorAleatorio.iniciar();
        Persona p1; int i=0;
        int dias=5;
        p1=new Persona(GeneradorAleatorio.generarString(3),GeneradorAleatorio.generarInt(50),GeneradorAleatorio.generarInt(90));
        Persona[][]casting=new Persona[dias][8];
        while(i<dias && !p1.getNombre().equals("zzz")){
            int j=0;
            while(j<8 && !p1.getNombre().equals("zzz") ){
                casting[i][j]=p1;
                p1=new Persona(GeneradorAleatorio.generarString(3),GeneradorAleatorio.generarInt(50),GeneradorAleatorio.generarInt(90));
                j++;
            }
            i++;    
        }
        int y=0;
        while(y<dias){
            int h=0;
            System.out.println("-----");
            while(h<8){
                System.out.println("en el dia: "+y+" en el turno: "+h+" fue: "+casting[y][h].toString());
                h++;
            }
            y++;     
        }
    }
}
//cuestionable el codigo, preg