/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package practica2;
import PaqueteLectura.GeneradorAleatorio;
public class ejercicio2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
      int df=14; int i=0;Persona p1; int dl;
      Persona[]contenedor=new Persona[df];
      GeneradorAleatorio.iniciar();
      p1=new Persona(GeneradorAleatorio.generarString(10),GeneradorAleatorio.generarInt(50),GeneradorAleatorio.generarInt(90));
      while(i<df && p1.getEdad()!=0){
        contenedor[i]=p1;
        i++;
        p1=new Persona(GeneradorAleatorio.generarString(10),GeneradorAleatorio.generarInt(50),GeneradorAleatorio.generarInt(90));
      }
      dl=i;
      int cant=0; int min=999;
      for (i=0;i<dl;i++){//preguntar si esta bien usado el i
          if(contenedor[i].getEdad()>65)
            cant++;
          if(contenedor[i].getDNI()<min)
            min=contenedor[i].getDNI();
          System.out.println(contenedor[i].toString());
      }
      
      System.out.println("la cantidad de personas mayores de 65 son: "+cant);
      System.out.println("el dni mas chico fue: "+min);
      
      
          
    }
    
}
