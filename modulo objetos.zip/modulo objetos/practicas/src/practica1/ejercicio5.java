/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package practica1;
import 
         PaqueteLectura.Lector;
public class ejercicio5 {
    public static void main(String[] args) {
      int restaurant[][];
      int i=0,num;
      restaurant=new int[3][4];
      while(i<=3){
        System.out.println("como estuvo la atencion: ");
        num=Lector.leerInt();
        restaurant[i][0]+=num;
        System.out.println("la calidad de la comida: ");
        num=Lector.leerInt();
        restaurant[i][1]+=num;
        System.out.println("el precio que le parecio: ");
        num=Lector.leerInt();
        restaurant[i][2]+=num;
        System.out.println("que le parecio el ambiente: ");
        num=Lector.leerInt();
        restaurant[i][3]+=num;
        i++;
      }
      int j,h,suma; double prom;
      for (j=0;j<3;j++){
          suma=0;
          for(h=0;h<4;h++)
             suma+=restaurant[j][h];
          System.out.println("el cliente: "+j+" su promedio fue: "+suma/1);
                  }
    }
    
}
