/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package practica1;

import 
         PaqueteLectura.Lector;
        
public class ejercicio4 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        //se puede hacer con el generador aleatorio importanto el paquete
       int numeroPiso,numeroOfi;
       int[][]edificio;
       edificio=new int[8][4];
       System.out.println("ingrese el piso de la persona: ");
       numeroPiso=Lector.leerInt();
       System.out.println("ingrese en la oficina que este: ");
       numeroOfi=Lector.leerInt();
       while(numeroPiso!=9){
           edificio[numeroPiso][numeroOfi]+=1;
           System.out.println("ingrese el piso de la persona: ");
           numeroPiso=Lector.leerInt();
           System.out.println("ingrese en la oficina que este: ");
           numeroOfi=Lector.leerInt();
       }
       int i,j;
       for (i=0;i<8;i++)
           for(j=0;j<4;j++)
               System.out.println("la cantidad de personas que hay en el piso: "+i+"en la oficina: "+j+" hay: "+edificio[i][j]);
    }
    
}
