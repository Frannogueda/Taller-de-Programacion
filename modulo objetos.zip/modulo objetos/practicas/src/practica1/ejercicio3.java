
package practica1;

//Paso 1. importar la funcionalidad para generar datos aleatorios
import PaqueteLectura.GeneradorAleatorio;
       import PaqueteLectura.Lector;
public class ejercicio3 {

    public static void main(String[] args) {
         //Paso 2. iniciar el generador aleatorio     
	  GeneradorAleatorio.iniciar(); 
        //Paso 3. definir la matriz de enteros de 5x5 e iniciarla con nros. aleatorios 
        int [][]matriz;
        matriz= new int [5][5];
        int suma=0,contador,i,j;
        for (i=0;i<5;i++)
            for (j=0;j<5;j++)
                matriz[i][j]=GeneradorAleatorio.generarInt(30);
        //Paso 4. mostrar el contenido de la matriz en consola
        for (i=0;i<5;i++){
            System.out.println(" ");
            for (j=0;j<5;j++)
                System.out.print(matriz[i][j]+"|");
        }
        //Paso 5. calcular e informar la suma de los elementos de la fila 1
        for (i=0;i<5;i++)
            suma+=matriz[0][i];
        System.out.println(" ");
        System.out.println("la suma de la primera fila es: "+suma);
        
        //Paso 6. generar un vector de 5 posiciones donde cada posición j contiene la suma de los elementos de la columna j de la matriz. 
        //        Luego, imprima el vector.
        int[]nuevaM;
        nuevaM=new int[5];
        for (i=0;i<5;i++){
            contador=0;
            for (j=0;j<5;j++)
                contador +=matriz[i][j];
            nuevaM[i]=contador;
            }
        for (j=0;j<5;j++)
               System.out.println("el valor en : "+j+" es "+ nuevaM[j]);
        //Paso 7. lea un valor entero e indique si se encuentra o no en la matriz. En caso de encontrarse indique su ubicación (fila y columna)
        //   y en caso contrario imprima "No se encontró el elemento".
        int posF=0,posC=0,numeroB;
        numeroB=Lector.leerInt();
        for (i=0;i<5;i++){
            for (j=0;j<5;j++){
                if(matriz[i][j]==numeroB){
                    posF =i;
                    posC =j;
                }
            }
        }
        if(posF==0&&posC==0)
                System.out.println("no se encontro el elemento");
            else
                System.out.println("el elemento esta en la posicion: "+posF+" "+posC);
}
}