
package practica1;

import PaqueteLectura.GeneradorAleatorio;

public class ejercicio2 {

  
    public static void main(String[] args) {
        //Paso 2: Declarar la variable vector de double 
        double[]jugadores;
        //Paso 3: Crear el vector para 15 double 
        jugadores=new double[15];
        //Paso 4: Declarar indice y variables auxiliares a usar
        int cantidad=0,i; double cant=0,promedio,num,max; 
        //Paso 6: Ingresar 15 numeros (altura), cargarlos en el vector, ir calculando la suma de alturas
        GeneradorAleatorio.iniciar();
        for (i=0;i<15;i++){
            num=GeneradorAleatorio.generarDouble(30);
            jugadores[i]=num;
            cant+=jugadores[i];
        }
        //Paso 7: Calcular el promedio de alturas, informarlo
            promedio=15/cant;
           System.out.println("el promedio del vector fue: "+ promedio);
        //Paso 8: Recorrer el vector calculando lo pedido (cant. alturas que están por encima del promedio)   
        for (i=0;i<15;i++)   
            if(jugadores[i]>promedio)
                System.out.println("el jugador en la posicion: "+i+" supero al promedio");
                cantidad+=1;
         //Paso 9: Informar la cantidad. 
        System.out.println("la cantidad que superaron al promedio fue: "+cantidad);
        }  
       
    }
