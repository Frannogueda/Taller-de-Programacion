/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package EmpresaBarrio;

/**
 *
 * @author frann
 */
public class Comprador {
    private int dni;
    private String nombreYapellido,ciudad;

    public Comprador(int dni, String nombreYapellido, String ciudad) {
        this.dni = dni;
        this.nombreYapellido = nombreYapellido;
        this.ciudad = ciudad;
    }

    
    public String persona() {
        return "mi dni: "+this.dni+ " mi nombre es: "+this.nombreYapellido+" y mi ciudad es: "+this.ciudad;
    }
    
}
