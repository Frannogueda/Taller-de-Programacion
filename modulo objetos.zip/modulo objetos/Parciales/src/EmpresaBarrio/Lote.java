/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package EmpresaBarrio;

/**
 *
 * @author frann
 */
public class Lote {
    private double precio=50000;//tendria que ser un setter para asignar pero no se como hacerlo :)
    private Comprador comprador;

    public Comprador getComprador() {
        return comprador;
    }

    public double getPrecio() {
        return precio;
    }

    @Override
    public String toString() {
        return this.comprador.persona();
    }
    
    //total=total-(5*total/100); ejemplo de porcentaje 
    
    public void sumaPorcen(int porcentaje){
        double total=this.precio;
        this.precio=total+(porcentaje*total/100);
    }
    
    public void agregarComprador(Comprador c){
        this.comprador=c;
    }

    public void setPrecio(double precio) {
        this.precio = precio;
    }
    
}
