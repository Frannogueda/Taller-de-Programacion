/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package EmpresaBarrio;

/**
 *
 * @author frann
 */
public class EmpresaB {
    private String nombreBarrio;
    private Lote lotes[][];
    private int n,m;
    
    public EmpresaB(String nombreBarrio,int m ,int n){
        this.nombreBarrio=nombreBarrio;
        this.m=m;
        this.n=n;
        inicializarLotes();
    }
    private void inicializarLotes(){
        lotes=new Lote[this.m][this.n]; 
        for(int i=0;i<this.m;i++)
            for(int j=0;j<this.n;j++){
                lotes[i][j]=new Lote();
            }    
    }
    public void incrementarPrecio(int manzana,int porcentaje){
        for(int j=0;j<this.n;j++)
            if(lotes[1-manzana][j].getComprador()==null)
                lotes[1-manzana][j].sumaPorcen(porcentaje);
    }
    
    public double totalRecaudado(){
        double total=0;
        for(int i=0;i<this.m;i++)
            for(int j=0;j<this.n;j++)
                if(lotes[i][j].getComprador()!=null){
                    total+=lotes[i][j].getPrecio();
                }
        return total;
    }
    public String toString(){
        String aux="";
        for(int i=0;i<this.m;i++){
            aux+="la manzana: "+(1+i)+"\n";
            for(int j=0;j<this.n;j++){
                aux+="el lote: "+(1+j)+" "+lotes[i][j].getPrecio();
                if(lotes[i][j].getComprador()==null){
                    aux+=" no hay comprador y esta disponible para la venta"+"\n";
                }else
                    aux+=" "+lotes[i][j].toString()+" no esta disponible para la venta"+"\n";
            }
        }
            
        return "barrio: "+this.nombreBarrio+" la recaudacion total: "+totalRecaudado()+"\n"+aux;
    }
    
    public void agregarComprador(Comprador c, int manzana,int Lote){
        lotes[manzana][Lote].agregarComprador(c);
    }
}
