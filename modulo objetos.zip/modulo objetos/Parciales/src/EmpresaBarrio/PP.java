/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package EmpresaBarrio;

/**
 *
 * @author frann
 */
public class PP {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        EmpresaB e; Comprador c;
        e=new EmpresaB("los teros",6,9);
        e.agregarComprador(c=new Comprador(345,"franco nogueda","la plata"),2,1);
        e.agregarComprador(c=new Comprador(456,"ezequiel tamame","la plata"),1,4);
        e.agregarComprador(c=new Comprador(124,"carlos aldo","villa elisa"),1,6);
        e.agregarComprador(c=new Comprador(896,"javier milei","recoleta"),3,6);
        e.agregarComprador(c=new Comprador(465,"lionel messi ","rosario"),3,4);
        
        e.incrementarPrecio(1,30);
        
        System.out.println(e.toString());
    }
    
}
