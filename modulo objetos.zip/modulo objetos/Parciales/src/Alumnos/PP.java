/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Alumnos;

/**
 *
 * @author frann
 */
public class PP {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        AlumnoGrado ag; AlumnoDoctorado ad;
        Materia m;
        ag=new AlumnoGrado(234,"franco",4,"informatica");
        ad=new AlumnoDoctorado(456,"adriana",4,"ingeniera","unlp");
        ag.agregaMateria(m=new Materia("oc",3,15));
        ag.agregaMateria(m=new Materia("capd",9,15));
        ag.agregaMateria(m=new Materia("tesis",10,4));
        ag.agregaMateria(m=new Materia("mate",7,30));
        ad.agregarMateria(m=new Materia("mate pi",4,2));
        ad.agregarMateria(m=new Materia("quimica",9,30));
        ad.agregarMateria(m=new Materia("transferencia",1,6));
        ad.agregarMateria(m=new Materia("ingenieria social",0,1));
        System.out.println(ag.toString());
        System.out.println("---------------------------------------");
        System.out.println(ad.toString());
    }
    
}
