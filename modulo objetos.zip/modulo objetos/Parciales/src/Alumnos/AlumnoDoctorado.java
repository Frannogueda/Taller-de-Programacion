/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Alumnos;

/**
 *
 * @author frann
 */
public class AlumnoDoctorado extends Alumno{
    private String titulo,universidadOrigen;
    
    public AlumnoDoctorado(int dni,String nombre,int cantMateriasA,String titulo,String universidadOrigen){
        super(dni,nombre,cantMateriasA);
        this.titulo=titulo;
        this.universidadOrigen=universidadOrigen;
    }
    public void agregarMateria(Materia m){
        super.agregaMateria(m);
    }
    
    public String toString(){
        String aux=super.toString();
        return aux+" "+"el titulo es: "+this.titulo+" y la universidad es: "+this.universidadOrigen;
    }

    public String getTitulo() {
        return titulo;
    }

    public String getUniversidadOrigen() {
        return universidadOrigen;
    }
    
    
}
