/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Alumnos;

/**
 *
 * @author frann
 */
public abstract class Alumno {
    private int dni;
    private String nombre;
    private Materia materias[];
    private int dl=0,df,TotalMaterias=3;//requiere 3 materias para recibirse 
    
    public Alumno(int dni,String nombre,int cantMateriasA){
        this.dni=dni;
        this.nombre=nombre;
        this.df=cantMateriasA;
        inicializarMaterias();
    }
    
    public String toString(){
        String aux="";
        for(int i=0;i<this.dl;i++)
            aux+=materias[i].getNombre()+" la nota: "+materias[i].getNota()+" y la fecha: "+materias[i].getFecha()+"\n";
        return "mi dni: "+this.dni+" mi nombre: "+this.nombre+" y mis materias aprobadas: "+"\n"+aux+this.estaGraduado();
    }
    
    public String estaGraduado(){ 
        boolean encontro=false; int i=0; String aux="";
        while(!encontro&i<this.df){
            if(materias[i].getNombre().equals("tesis")){
                encontro=true;
            }else{
               i++; 
            }
        }
        if(encontro){
            if(this.df>=this.TotalMaterias){
                aux= "esta graduado";
            }
        }else{
            aux= "no esta graduado";
        } 
       return aux;
    }
    
    public void agregaMateria(Materia m){
        if(this.dl<this.df){
            materias[this.dl]=m;
            this.dl++;
        }
    }
    
    private void inicializarMaterias(){
        materias=new Materia[this.df];
        for (int i=0;i<this.df;i++){
            materias[i]=null;
        }
    }
}
