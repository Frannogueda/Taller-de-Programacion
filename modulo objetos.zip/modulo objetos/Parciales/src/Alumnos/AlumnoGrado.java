/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Alumnos;

/**
 *
 * @author frann
 */
public class AlumnoGrado extends Alumno{
    private String carrera;
    
    public AlumnoGrado(int dni,String nombre,int cantMateriasA,String carrera){
        super(dni,nombre,cantMateriasA);
        this.carrera=carrera;
    }
    
    public String toString(){
        String aux=super.toString();
        return aux+" y mi carrera: "+this.carrera;
    }
    
    public void agregarMateria(Materia m){
        super.agregaMateria(m);
    }
    
}
