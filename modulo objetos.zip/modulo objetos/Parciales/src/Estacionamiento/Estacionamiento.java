/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Estacionamiento;

/**
 *
 * @author frann
 */
public class Estacionamiento {
    private String direccion;
    private double costoXHora;
    private int sector,lugares;
    private vehiculo vehiculos[][];
    
    public Estacionamiento(String direccion,double costoXHora,int Sector,int cantV){
        this.direccion=direccion;
        this.costoXHora=costoXHora;
        this.lugares=cantV;
        this.sector=Sector;
        inicializarEstacionamiento(Sector,cantV);
    }
    private void inicializarEstacionamiento(int Sector,int cantV){
        vehiculos=new vehiculo[Sector][cantV];
        for(int i=0;i<Sector;i++)
            for(int j=0;j<cantV;j++)
                vehiculos[i][j]=null;
    }
    
    public void registrarVehiculo(vehiculo v,int sector,int lugar){
        if(vehiculos[sector][lugar]==null)
            vehiculos[sector][lugar]=v;
    }
    
    public String liberarLugares(String marca,int sector){
        String aux="";
        for(int u=0;u<this.lugares;u++){
            if(vehiculos[sector][u]!=null){
               if(vehiculos[sector][u].getMarca().equals(marca)){
                aux+=vehiculos[sector][u].toString()+"\n";
                vehiculos[sector][u]=null; 
                } 
            }
        }
        return aux;    
    }
    public int mayorRecaudacion(){
        double max=0,total; int maxS=0;
        for (int i=0;i<this.sector;i++){
            total=0;
            for(int j=0;j<this.lugares;j++){
                if(vehiculos[i][j]!=null)
                    total+=this.costoXHora*vehiculos[i][j].getCantHoras();
            }
            if(total>max){
                max=total;
                maxS=i+1;
            }
        }
        return maxS;
    }
    
    public String toString(){
        String aux="";
        aux+="la direccion: "+this.direccion+" y su costo: "+this.costoXHora+"\n";
        for(int r=0;r<this.sector;r++){
            aux+="el sector: "+r+"\n";//podria declarar f afuera asi queda mas prolijo a la hora de llamar a los sectores en el P.P
            for(int f=0;f<this.lugares;f++){
               if(vehiculos[r][f]!=null)
                   aux+=vehiculos[r][f].toString()+"\n";
            }  
        }
      return aux;           
    }

    private String getDireccion() {
        return direccion;
    }

    private double getCostoXHora() {
        return costoXHora;
    }
    
    
}
