/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Estacionamiento;

/**
 *
 * @author frann
 */
public class vehiculo {
    private int patente;
    private double cantHoras;
    private String marca,modelo;
    
    public String toString(){
        return "patente: "+this.patente+" la cantidad de horas: "+this.cantHoras+" la marca: "+this.marca+" y su modelo: "+this.modelo;
    }

    public vehiculo(int patente, double cantHoras, String marca, String modelo) {
        this.patente = patente;
        this.cantHoras = cantHoras;
        this.marca = marca;
        this.modelo = modelo;
    }

    
    public double getCantHoras() {
        return cantHoras;
    }
    

    public String getMarca() {
        return marca;
    }
}
