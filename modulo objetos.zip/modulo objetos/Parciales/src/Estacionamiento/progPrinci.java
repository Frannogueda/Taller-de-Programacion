/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Estacionamiento;

/**
 *
 * @author frann
 */
public class progPrinci {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Estacionamiento e; vehiculo v;
        e=new Estacionamiento("calle 7",30.4,5,5);
        e.registrarVehiculo(v=new vehiculo(345,7,"corsa","pepe"),0,0);
        e.registrarVehiculo(v=new vehiculo(45,1,"toyota","moustro"),0,1);
        e.registrarVehiculo(v=new vehiculo(596,5,"corsa","kipe"),2,0);
        e.registrarVehiculo(v=new vehiculo(123,2.30,"toyota","espert"),3,4);
        e.registrarVehiculo(v=new vehiculo(987,1,"honda","adsad"),4,2);
        System.out.println("el mayor sector que recaudo fue:");
        System.out.println(e.mayorRecaudacion());
        System.out.println(e.toString());
        System.out.println("liberamos los vehiculos: ");
        System.out.println(e.liberarLugares("toyota",3));
    }
    
}
