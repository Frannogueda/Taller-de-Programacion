/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Curso;

/**
 *
 * @author frann
 */
public class progPrinci {
    // dentro de la carpeta esta el parcial 
    
    public static void main(String[] args) {
        CursoOnline co; CursoPresencial cp; leccion l;
        cp=new CursoPresencial("MarPlatence",15.3,5,2,true);
        co=new CursoOnline("messiInterprise",15.3,5,"zoom");
        cp.agregarLeccion(l=new leccion("terraplanismo",15,30));
        cp.agregarLeccion(l=new leccion("neonazis",2,60));
        cp.agregarLeccion(l=new leccion("milei",30,10));
        co.agregarLeccion(l=new leccion("crisis",23,30));
        co.agregarLeccion(l=new leccion("CFK",6,10));
        System.out.println(cp.toString());
        System.out.println(co.toString());

    }
}
