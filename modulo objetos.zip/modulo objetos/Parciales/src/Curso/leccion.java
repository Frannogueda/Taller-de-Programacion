/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Curso;

/**
 *
 * @author frann
 */
public class leccion {
    private String tema;
    private int fecha,minutos;

    @Override
    public String toString() {
        return "el tema es: "+this.getTema()+" su fecha: "+this.getFecha()+" y sus minutos: "+this.getMinutos()+ "\n";
    }

    public leccion(String tema, int fecha, int minutos) {
        this.tema = tema;
        this.fecha = fecha;
        this.minutos = minutos;
    }
    

    public String getTema() {
        return tema;
    }

    public void setTema(String tema) {
        this.tema = tema;
    }

    public int getFecha() {
        return fecha;
    }

    public void setFecha(int fecha) {
        this.fecha = fecha;
    }

    public int getMinutos() {
        return minutos;
    }

    public void setMinutos(int minutos) {
        this.minutos = minutos;
    }
}
