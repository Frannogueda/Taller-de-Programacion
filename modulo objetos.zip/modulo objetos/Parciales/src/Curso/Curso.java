/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Curso;

/**
 *
 * @author frann
 */
public abstract class Curso {
    private String nombre;
    private double costoLeccion;
    private leccion lecciones[];
    private int DF,DL;//cuando se agrega una lecciones sumamos 1 a DL
    
    public Curso(String nombre,double costoLeccion, int cantLecciones){
        this.setNombre(nombre);
        this.setCostoLeccion(costoLeccion);
        DF=cantLecciones;
        DL=0;
        lecciones=new leccion[cantLecciones];//requirira inicilizar en null? por las dudas lo hago
        iniciliazarLecciones();
    } 
    public void agregarLeccion(leccion l){
        lecciones[DL]=l;
        DL++;
    }
    public abstract double costoFinal();
    
    @Override
    public String toString(){
        String aux="";
        for(int e=0;e<DL;e++)
            aux+=lecciones[e].toString();
        return this.getNombre()+" las lecciones son: "+aux+" y su costo es: "+this.costoFinal();
    }

    public int getDL() {
        return DL;
    }
    
    public void iniciliazarLecciones(){
        for(int i=0;i<DF;i++)
            lecciones[i]=null;
    }
    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public double getCostoLeccion() {
        return costoLeccion;
    }

    public void setCostoLeccion(double costoLeccion) {
        this.costoLeccion = costoLeccion;
    }
    
}
