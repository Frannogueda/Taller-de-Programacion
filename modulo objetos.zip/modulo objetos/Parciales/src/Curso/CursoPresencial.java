/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Curso;

/**
 *
 * @author frann
 */
public class CursoPresencial extends Curso{
    private int Aula;
    private boolean coffeTime;
    
    public CursoPresencial(String nombre,double costoLeccion, int cantLecciones,int Aula,boolean coffeTime){
        super(nombre,costoLeccion,cantLecciones);
        this.setAula(Aula);
        this.setCoffeTime(coffeTime);
    }
    public void agregarLeccion(leccion l){
        super.agregarLeccion(l);
    }
    
    public double costoFinal(){
     double total=super.getDL()*super.getCostoLeccion();
     if(this.isCoffeTime()){
         total=total-(5*total/100);
            return total;
        }else
            return total;
    }

    public int getAula() {
        return Aula;
    }

    public void setAula(int Aula) {
        this.Aula = Aula;
    }

    public boolean isCoffeTime() {
        return coffeTime;
    }

    public void setCoffeTime(boolean coffeTime) {
        this.coffeTime = coffeTime;
    }
    
}
