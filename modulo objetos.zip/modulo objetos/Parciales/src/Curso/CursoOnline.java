/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Curso;

/**
 *
 * @author frann
 */
public class CursoOnline extends Curso{
    private String plataforma;
    
    public CursoOnline(String nombre,double costoLeccion, int cantLecciones,String plataforma){
        super(nombre,costoLeccion,cantLecciones);
        this.setPlataforma(plataforma);
    }
    @Override
    public void agregarLeccion(leccion l){//no se si estara bien implementarlo asi 
        if(l.getMinutos()<45){
            super.agregarLeccion(l);
        }
    }
    public double costoFinal(){
        double total=super.getDL()*super.getCostoLeccion();
        if(this.getPlataforma().equals("zoom")){
            total=total-(10*total/100);
            return total;
        }else
            return total;
    }

    public String getPlataforma() {
        return plataforma;
    }

    private void setPlataforma(String plataforma) {//la pongo privada para que solo lo modifique la clase
        this.plataforma = plataforma;
    }
    
}
