/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Empresa;

/**
 *
 * @author frann
 */
public class Director {
    private String nombre;
    private int dni,anioIngreso;
    private double sueldo,MontoDV;

    public Director(String nombre, int dni, int anioIngreso, double sueldo, double MontoDV) {
        this.nombre = nombre;
        this.dni = dni;
        this.anioIngreso = anioIngreso;
        this.sueldo = sueldo;
        this.MontoDV = MontoDV;
    }

    @Override
    public String toString() {
        return "mi nombre: "+this.nombre+" mi dni: "+this.dni+" y mi sueldo a cobrar: "+this.cobroD()+"\n";
    }
    
    public double cobroD(){
        int aux=2023-this.anioIngreso;
        double totalS=this.sueldo;
        if(aux>=20)
            totalS=totalS+(10*totalS/100);
        return totalS+this.MontoDV;
    }
}
