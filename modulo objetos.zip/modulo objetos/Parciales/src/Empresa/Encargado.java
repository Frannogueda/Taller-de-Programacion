/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Empresa;

/**
 *
 * @author frann
 */
public class Encargado {
    private String nombre;
    private int dni,anioIngreso,cantEmpleadosC;
    private double sueldo;
    
    public Encargado(String nombre, int dni, int anioIngreso, int cantEmpleadosC, double sueldo) {
        this.nombre = nombre;
        this.dni = dni;
        this.anioIngreso = anioIngreso;
        this.cantEmpleadosC = cantEmpleadosC;
        this.sueldo = sueldo;
    }
    @Override
    public String toString(){
        return " Mi nombre es: "+this.nombre+" mi dni: "+this.dni+" y mi sueldo a cobrar es: "+cobroE();
    }
    
    public double cobroE(){
        int aux=2023-this.anioIngreso;
        double totalS=this.sueldo;
        if(aux>=20)
            totalS=totalS+(10*totalS/100);
        return totalS+(this.cantEmpleadosC*1000);
    }
    
}
