/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Empresa;

/**
 *
 * @author frann
 */
public class Empresa {
    private String nombre,direccion;
    private Director direc;
    private Encargado sucursal[];
    private int df;
    
    public Empresa(String nombre,String direccion,Director direc,int cantSucu){
        this.nombre=nombre;
        this.direccion=direccion;
        this.direc=direc;
        this.df=cantSucu;
        InicializarSucursales();// se puede aclarar como inicializar y esta bien para el parcial 
    }
    private void InicializarSucursales(){
        sucursal=new Encargado[this.df];
        for(int i=0;i<this.df;i++)
            sucursal[i]=null;
    }
    
    public double sueldoTotal(){
        double aux=0;
        for(int i=0;i<this.df;i++){
            if(sucursal[i]!=null)
                aux+=sucursal[i].cobroE();
        }
        return this.direc.cobroD()+aux;
    }
    
    private String direcYEncarga(){
        String aux="",aux2="";
        for(int i=0;i<this.df;i++)
            if(sucursal[i]!=null)
                aux+="mi sucursal es: "+(i+1)+sucursal[i].toString()+"\n";
            else
                aux+="la sucursal: "+(i+1)+" no tiene encargado"+"\n";
        return this.direc.toString()+aux+aux2;
    }
    @Override
    public String toString(){
        return "la empresa: "+this.nombre+" se encuentra: "+this.direccion+"\n"+this.direcYEncarga();
    }
    
    public void asignarEncargado(Encargado e,int Sucursal){
        sucursal[Sucursal]=e;
    }
    
}
