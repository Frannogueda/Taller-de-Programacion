/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Empresa;

/**
 *
 * @author frann
 */
public class PP {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        //este programa funciona bien pero en el encargado y direc repito codigo y no se si es lo mejor para este caso
        //tendria que ser usa superclaro de "persona" para heredar hacia el encargado y director
        //se ve mas en el punto 2 y 3. PARA REVISAR S
        
        Empresa e; Director d=new Director("franco",342,1940,20000,10000); Encargado en;
        
        e=new Empresa("francoInterprise","en 8",d,10);
        
        e.asignarEncargado(en=new Encargado("pepe",234,1950,10,30000),1);
        e.asignarEncargado(en=new Encargado("jose",1234,1990,3,20000),5);
        e.asignarEncargado(en=new Encargado("hector",254,2000,50,10000),8);
        e.asignarEncargado(en=new Encargado("adriana",346,1970,30,45000),9);
        
        System.out.println(e.toString());
    }
    
}
