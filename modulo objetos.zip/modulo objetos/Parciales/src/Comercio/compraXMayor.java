/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Comercio;

/**
 *
 * @author frann
 */
public class compraXMayor extends Compra{
    private int cuil;
    private String nombre;
    
    public compraXMayor(int n){
        super(n);
        this.cuil=234;
        this.nombre="Franco Nogueda";
    }
    @Override
    public void AgregarProducto(Producto p){
        if(p.getCantUnidad()>6)
            super.AgregarProducto(p);
    }
    @Override
    public double precioFinal(){
        double total=super.precioFinal();
        total=total-(21*total/100);
        return total;
    }
    
}
