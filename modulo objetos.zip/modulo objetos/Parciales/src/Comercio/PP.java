/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Comercio;

/**
 *
 * @author frann
 */
public class PP {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Compra C=new Compra(10); compraXMayor cm= new compraXMayor(10); Producto p;
        
        C.AgregarProducto(p=new Producto(12,4,"ñam ñam",20.0));
        C.AgregarProducto(p=new Producto(23,1,"ñam ñam",10.0));
        C.AgregarProducto(p=new Producto(152,6,"ñam ñam",50.0));
        C.AgregarProducto(p=new Producto(102,3,"ñam ñam",80.0));
        C.AgregarProducto(p=new Producto(562,2,"ñam ñam",40.0));
        
        cm.AgregarProducto(p=new Producto(123,7,"cosita",30.5));
        cm.AgregarProducto(p=new Producto(53,13,"cosita",60.5));
        cm.AgregarProducto(p=new Producto(1213,53,"cosita",90.5));
        cm.AgregarProducto(p=new Producto(164,1245,"cosita",100.5));
        cm.AgregarProducto(p=new Producto(192,8,"cosita",40.0));
        
        System.out.println(C.resumen());
        System.out.println(C.cuotas());
        System.out.println("-----------------------------");
        System.out.println(cm.resumen());
        System.out.println(cm.cuotas());
    }
    
}
