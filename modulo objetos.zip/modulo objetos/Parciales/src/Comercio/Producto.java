/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Comercio;

/**
 *
 * @author frann
 */
public class Producto {
    private int codigo,cantUnidad;
    private String descripcion;
    private double precioXU;

    public int getCantUnidad() {
        return cantUnidad;
    }

    public Producto(int codigo, int cantUnidad, String descripcion, double precioXU) {
        this.codigo = codigo;
        this.cantUnidad = cantUnidad;
        this.descripcion = descripcion;
        this.precioXU = precioXU;
    }
    
    @Override
    public String toString(){
        return "El codigo: "+this.codigo+"\n"+"La Descripcion: "+this.descripcion+"\n"+"El precio total es: "+this.precioTotal();
    }
    
    public double precioTotal(){
        return this.precioXU*this.cantUnidad;
    }
}
