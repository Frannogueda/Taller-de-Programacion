/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Comercio;

/**
 *
 * @author frann
 */
public class Compra {
    private int numero;
    private Fecha fecha;
    private Producto producto[];
    private int dl=0,df;
    
    public Compra(int n){
        this.numero=123;
        this.fecha=new Fecha(14,2,2000);
        this.df=n;
        inicializar();
    }
    
    public String resumen(){
        String aux="";
        for (int i=0;i<this.dl;i++)
            aux+=producto[i].toString()+"\n";
        return "el numero: "+this.numero+" la fecha: "+fecha.toString()+" el codigo: "+"\n"+aux+"el total de la compra es:"+this.precioFinal();
    }
    
    public double precioFinal(){
        double total=0;
        for(int i=0;i<this.dl;i++)
            total+=producto[i].precioTotal();
        return total;
    }
    
    public boolean cuotas(){
        return this.precioFinal()>100000;
    }
    
    public void AgregarProducto(Producto p){
        producto[this.dl]=p;
        this.dl++;
    }
    private void inicializar(){
        producto=new Producto[this.df];
        for(int i=0;i<this.df;i++)
            producto[i]=null;
    }
}
