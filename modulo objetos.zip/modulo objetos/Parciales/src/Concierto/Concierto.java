/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Concierto;

/**
 *
 * @author frann
 */
public class Concierto {
    private String nombreArtista;
    private double precioEntrada;
    private int cantEntradasV;

    public Concierto(String nombreArtista, double precioEntrada, int cantEntradasV) {
        this.nombreArtista = nombreArtista;
        this.precioEntrada = precioEntrada;
        this.cantEntradasV = cantEntradasV;
    }
    
    public double totalGanado(){
        return this.precioEntrada*this.cantEntradasV;
    }

    @Override
    public String toString() {
        return this.nombreArtista+" el precio fue de: "+this.precioEntrada+" la cantidad que vendio fue: "+this.cantEntradasV;
    }
  
}
