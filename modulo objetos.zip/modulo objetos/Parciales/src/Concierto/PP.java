/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Concierto;

/**
 *
 * @author frann
 */
public class PP {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Estadio e; Concierto c;
        e=new Estadio("obras","en 7",20000);
        e.registrarConcierto(1,c=new Concierto("cazzu",20,3));
        e.registrarConcierto(4,c=new Concierto("pepe",300,500));
        e.registrarConcierto(2,c=new Concierto("miw",5000,20000));
        e.registrarConcierto(1,c=new Concierto("lorna shore",50,60000));
        e.registrarConcierto(5,c=new Concierto("guns",40,300023));
        e.registrarConcierto(7,c=new Concierto("bob",10,3000));
        e.registrarConcierto(9,c=new Concierto("peter",10,200));
        e.registrarConcierto(2,c=new Concierto("miranda",3,60));
        e.registrarConcierto(3,c=new Concierto("julio iglesias",100,58374));
        e.registrarConcierto(5,c=new Concierto("lali",222000,5));
        
        System.out.println(e.gananciasMes(1));
        System.out.println("-------------------");
        System.out.println(e.listaMes(2));
        System.out.println("--------------------");
        System.out.println(e.toString());
    }
    
}
