/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Concierto;

/**
 *
 * @author frann
 */
public class Estadio {
    private String nombre,direccion;
    private int capacidad;
    private Concierto calendario[][];
    private int mes,dia;

    public Estadio(String nombre, String direccion, int capacidad) {
        this.nombre = nombre;
        this.direccion = direccion;
        this.capacidad = capacidad;
        this.mes = 12;
        this.dia = 31;
        InicializarCalendario();
    }
    private void InicializarCalendario(){
        calendario=new Concierto[this.mes][this.dia];
        for(int i=0;i<this.mes;i++)
            for(int j=0;j<this.dia;j++)
                calendario[i][j]=null;
    }
    
    public double gananciasMes(int mes){
        double total=0;
        for(int r=0;r<this.dia;r++)
            if(calendario[mes][r]!=null)
                total+=calendario[mes][r].totalGanado()/2;
        return total;
    }
    
    public String toString(){
        String aux="";
        for(int i=0;i<this.mes;i++){
            aux+="el mes: "+(1+i)+"\n";
            for(int j=0;j<this.dia;j++){
                if(calendario[i][j]!=null)
                    aux+="el dia: "+(1+j)+" se presento: "+calendario[i][j].toString()+"\n";
            }
        }
        return "el estadio: "+this.nombre+" y la direccion: "+this.direccion+"\n"+aux;
    }
    
    public void registrarConcierto(int mes,Concierto c){
        int i=0;
        while(calendario[mes][i]!=null)
            i++;
        calendario[mes][i]=c;
    }
    public String listaMes(int mes){
        String aux="";
        for(int i=0;i<this.dia;i++)
            if(calendario[mes][i]!=null)
                aux+=calendario[mes][i].toString();
        return aux;
    }
    
    
}
