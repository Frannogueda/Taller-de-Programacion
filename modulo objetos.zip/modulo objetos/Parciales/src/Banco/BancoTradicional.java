/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Banco;

/**
 *
 * @author frann
 */
public class BancoTradicional extends Banco{
    private String localidad,direccion;
    private int cantCD=100,totalCD=0;//totalCD es para ver que no supere la cantidad de cuentas que hay 
    
    public BancoTradicional(String nombre,int cantEmpleados,int cantCuentas,String localidad,String direccion,int cantCD){
        super(nombre,cantEmpleados,cantCuentas);
        this.localidad=localidad;
        this.direccion=direccion;
        this.totalCD=cantCD;
    }
    
    public boolean puedeRecibirTarjeta(int cbu){
        Cuenta aux=super.ObtenerCuenta(cbu); boolean pudo;
        if(aux.getMoneda().equals("pesos")&aux.getMonto()>70000){
            pudo=true;
        }else{
            pudo = aux.getMoneda().equals("dolar")&aux.getMonto()>=500;
        }
        return pudo;
    }
    
    public Boolean agregaCuenta(Cuenta c){
        boolean sePudo=true;
        if(this.totalCD<this.cantCD){
            if(c.getMoneda().equals("dolar")){//pregunta si es igual a una cuenta en dolares
                this.totalCD++;
                sePudo=super.meteCuenta(c);
            }else{
                sePudo=super.meteCuenta(c);
            } 
        }else{
            sePudo=super.meteCuenta(c);
        }
        return sePudo;
    }
}
