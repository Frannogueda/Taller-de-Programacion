/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Banco;

/**
 *
 * @author frann
 */
public class BancoDigital extends Banco{
    private String web;
    
    public BancoDigital(String nombre,int cantEmpleados,int cantCuentas,String web){
        super(nombre,cantEmpleados,cantCuentas);
        this.web=web;
    }
    
    public boolean puedeRecibirTarjeta(int cbu){
        boolean puede=false; Cuenta aux=super.ObtenerCuenta(cbu);
        if(aux.getMoneda().equals("pesos")&aux.getMonto()>100000)
            puede=true;
        return puede;
    }
    
    public boolean agregaCuenta(Cuenta c){
        return super.meteCuenta(c);
    }
}
