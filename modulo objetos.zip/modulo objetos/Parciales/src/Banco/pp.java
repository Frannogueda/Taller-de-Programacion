/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Banco;

/**
 *
 * @author frann
 */
public class pp {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        BancoTradicional bt; BancoDigital bd; Cuenta c;
        bt=new BancoTradicional("banco central",15,200,"la plata","7",50);
        bd=new BancoDigital("galicia",4,300,"safari");
        
        bt.agregaCuenta(c=new Cuenta(123,435,"yuyo","pesos",90000));// si usas un sout te devuelve el true 
        bt.agregaCuenta(c=new Cuenta(145,321,"pepe","dolar",200));
        bt.agregaCuenta(c=new Cuenta(112,001,"milei","pesos",80000));
        bt.agregaCuenta(c=new Cuenta(865,123,"cfk","pesos",1000000));
        bt.agregaCuenta(c=new Cuenta(753,533,"mujica","pesos",70123));
        
        bd.agregaCuenta(c=new Cuenta(123,45,"yuyo","dolar",23042));
        bd.agregaCuenta(c=new Cuenta(134,754,"jose","pesos",901831));
        bd.agregaCuenta(c=new Cuenta(002,876,"josefina","real",57293));
        bd.agregaCuenta(c=new Cuenta(467,123,"sofia","pesos",9238457));
        bd.agregaCuenta(c=new Cuenta(435,643,"adrian","canadienses",1823761));
        
        bt.depositarDinero(123,3002);
        bd.depositarDinero(134,30042);
        
        System.out.println(bt.puedeRecibirTarjeta(123));
        
        System.out.println(bd.puedeRecibirTarjeta(467));
    }
    
}
