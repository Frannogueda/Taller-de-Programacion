/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Banco;

/**
 *
 * @author frann
 */
public abstract class Banco {
    private String nombre;
    private int cantEmple,df,dl=0;
    private Cuenta cuentas[];
    
    public boolean meteCuenta(Cuenta c){
        boolean sePudo;
        if(this.dl<this.df){
            cuentas[this.dl]=c;
            this.dl++;
            sePudo=true;
        }else{
            sePudo=false;
        }
       return sePudo;
    }
    
    public void depositarDinero(int cbu,double monto){
        boolean encontro=false; int j=0; 
        while(!encontro&j<this.dl)
            if(cuentas[j].getcbu()==cbu){
                cuentas[j].metePlata(monto);
                encontro=true;
            }else{
                j++;
            }
    }
    
    public abstract boolean puedeRecibirTarjeta(int cbu);
    
    public Cuenta ObtenerCuenta(int cbu){//podria devolver el toString pero me sirve el metedo para puedeRecibirTarjeta
        boolean encontro=false; int i=0; Cuenta aux = null;
        while(!encontro&i<this.dl){
            if(cuentas[i].getcbu()==cbu){
                encontro=true;
            }else{
                i++;
            } 
        }
        if(cuentas[i].getcbu()==cbu){
            aux=cuentas[i];
        }
        return aux;
    }
    public Banco(String nombre,int cantEmpleados,int cantCuentas){
        this.nombre=nombre;
        this.cantEmple=cantEmpleados;
        this.df=cantCuentas;
        InicializarCuentas();
    }
    private void InicializarCuentas(){
        cuentas=new Cuenta[this.df];
        for(int i=0;i<this.df;i++)
            cuentas[i]=null;
    }
    
}

