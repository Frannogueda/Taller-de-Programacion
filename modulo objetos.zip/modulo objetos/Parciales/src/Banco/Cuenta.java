/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Banco;

/**
 *
 * @author frann
 */
public class Cuenta {
    private int cbu,dniT;
    private String alias,moneda;
    private double monto=0;
    
    public void metePlata(double monto){
        this.monto=this.monto+monto;
    }

    public String getMoneda() {
        return moneda;
    }

    public double getMonto() {
        return monto;
    }

    @Override
    public String toString() {
        return "mi cbu:" +  this.cbu +"/n"+"mi dni: "+this.dniT+"/n"+"mi alias: "+this.alias;
    }

    public void setMonto(double monto) {
        this.monto = monto;
    }
    
    public int getcbu(){
        return cbu;
    }
    public Cuenta(int cbu, int dniT, String alias, String moneda, double monto) {
        this.cbu = cbu;
        this.dniT = dniT;
        this.alias = alias;
        this.moneda = moneda;
        this.monto = monto;
    }
    
}
