/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Surtidores;

/**
 *
 * @author frann
 */
public class Estacion {
    private String direccion;
    private Surtidor Surtidores[];
    private int dl=0;

    public void agregarSurtidor(Surtidor s){
        this.Surtidores[dl]=s;
        this.dl++;
    }
    
    public void generarVenta(int numS,int dni,double cantLitros,String formaPago){
        Surtidores[numS-1].vende(dni,cantLitros,formaPago);
    }
    
    public int mayorRecaudador(){
        double max=-1; int maxN=0;
        for(int i=0;i<this.dl;i++){
            if(this.Surtidores[i].totalRecaudado()>max){
                max=this.Surtidores[i].totalRecaudado();
                maxN=dl+1;        
            }
        }
        return maxN;
    }
    @Override
    public String toString(){
        String aux="";
        aux+="La estacion es: "+this.getDireccion()+" la cantidad de surtidores: "+this.dl+"\n";
        for (int i = 0; i < this.dl; i++) {
            aux += "Surtidor "+ (i+1)+" "+ this.Surtidores[i].getCombustibleD()+
                    " precio por litro = "+this.Surtidores[i].getPrecioXLitro()+": \n";
        }
        return aux;
    }
    
    public Estacion(String direccion){
        this.direccion=direccion;
        this.Surtidores=new Surtidor[6];
    }
   
    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }
}
