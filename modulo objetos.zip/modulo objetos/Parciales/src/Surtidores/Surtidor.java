/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Surtidores;

/**
 *
 * @author frann
 */
public class Surtidor {
    private String CombustibleD;
    private double precioXLitro;
    private Venta ventas[];
    private int dl=0,df;
    
    public Surtidor(String combustibleD,double precioXLitro,int capacidadMaxVentas){
        this.CombustibleD=combustibleD;
        this.precioXLitro=precioXLitro;
        this.ventas=new Venta[capacidadMaxVentas];
        this.df=capacidadMaxVentas;
    }
    
    public void vende(int dni,double cantLitros,String formaPago){
        double total=cantLitros*this.getPrecioXLitro();
        ventas[dl]=new Venta(dni,cantLitros,total,formaPago);
        this.dl++;
    }
    
    public double totalRecaudado(){
        double totalVentas=0;
        for(int i=0;i<dl;i++)
            totalVentas+=ventas[i].getMontoAbonado();
        return totalVentas;
    }

    public String getCombustibleD() {
        return CombustibleD;
    }

    public void setCombustibleD(String CombustibleD) {
        this.CombustibleD = CombustibleD;
    }

    public double getPrecioXLitro() {
        return precioXLitro;
    }

    public void setPrecioXLitro(double precioXLitro) {
        this.precioXLitro = precioXLitro;
    }
    
}
