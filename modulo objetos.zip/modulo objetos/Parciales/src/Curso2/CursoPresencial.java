/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Curso2;

/**
 *
 * @author frann
 */
public class CursoPresencial extends Curso{
    private int numAula;
    
    public CursoPresencial(){
        this.numAula=3;
    }
    
    public boolean puedeRendir(Alumno a){
        boolean aux=false;
        if(a.getAsistencias()>=3)
            aux=true;
        return aux;
    }
}
