/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Curso2;

/**
 *
 * @author frann
 */
public class Alumno {
    private int dni,asistencias=0,cantEA=0;
    private String nombre;

    public Alumno(int dni, String nombre) {
        this.dni = dni;
        this.nombre = nombre;
    }

    public int getDni() {
        return dni;
    }

    public int getAsistencias() {
        return asistencias;
    }

    public int getCantEA() {
        return cantEA;
    }
    
    public void iA(){
        this.asistencias++;
    }
    
    public void iAE(){
        this.cantEA++;
    }
}
