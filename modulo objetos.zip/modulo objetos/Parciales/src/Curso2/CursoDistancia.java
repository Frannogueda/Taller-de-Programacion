/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Curso2;

/**
 *
 * @author frann
 */
public class CursoDistancia extends Curso{
    private String link;
    
    public CursoDistancia(){
        this.link="cosanostta";
    }
    public boolean puedeRendir(Alumno a){
        boolean aux=false;
        if(a.getCantEA()>=1&a.getAsistencias()>=3)
            aux=true;
        return aux;
    }
}
