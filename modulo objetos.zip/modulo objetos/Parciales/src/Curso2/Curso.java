/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Curso2;

/**
 *
 * @author frann
 */
public abstract class Curso {
    private int anioC;
    private Alumno alumnos[];
    private int df,dl=0;
    
    public Curso(){
        this.anioC=2023;
        this.df=10;
        alumnos=new Alumno[this.df];
        //se inicializa en null?
    }
    
    public boolean AgregarAlumno(Alumno a){
        boolean aux;
        if(this.dl<this.df){
            alumnos[this.dl]=a;
            this.dl++;
            aux=true;
        }else
            aux=false;
       return aux;
    }
    
    public int busqueda(int dni){
        int i=0,aux=0;
        while(alumnos[i].getDni()!=dni&i<this.df)
            i++;
        if(alumnos[i].getDni()==dni)
            aux=i;
        return aux;
    }
    public int cantRendir(){
        int aux=0;
        for(int i=0;i<this.dl;i++)
            if(this.puedeRendir(alumnos[i]))
                aux++;
        return aux;
    }
    public abstract boolean puedeRendir(Alumno a);
    
    public void incrementarAsist(int dni){
        alumnos[this.busqueda(dni)].iA();
    }
    
    public void incrementarAutoE(int dni){
        alumnos[this.busqueda(dni)].iAE();
    }
    
}
