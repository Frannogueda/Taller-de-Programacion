/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Curso2;

/**
 *
 * @author frann
 */
public class PP {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        CursoDistancia cd; CursoPresencial cp; Alumno a=new Alumno(2343,"franco");
        cd=new CursoDistancia(); cp=new CursoPresencial();
        cd.AgregarAlumno(a);
        cd.incrementarAsist(2343);
        cd.incrementarAsist(2343);
        cd.incrementarAsist(2343);
        cd.incrementarAutoE(2343);//tiene la condicion para rendir 
        System.out.println(cd.puedeRendir(a));
        
        
    }
    
}
